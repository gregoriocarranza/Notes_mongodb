import express from "express"
import { Server as WebSocketServer } from "socket.io"
import http from "http"
import { v4 as uuid } from 'uuid';

let notes = []

const app = express()
const server = http.createServer(app)
const io = new WebSocketServer(server)

app.use(express.static(__dirname + "/public"))

const PORT = process.env.PORT || 3000
app.get("/", (req, res) => {
    console.log(`Hola`)
    res.send("Hola user")
})

io.on("connection", (socket) => {
    console.log("Nueva Coneccion: ", socket.id)

    socket.emit(`server:loadNotes`, notes)

    socket.on(`client:newNote`, newNote => {
        const note = { ...newNote, id: uuid() }
        // console.log(note)
        notes.push(note)
        io.emit(`server:renderNotes`, note)
    })
    socket.on(`client:deletenote`, id => {
        console.log(`Borrando nota con el id: ${id}`)
        notes = notes.filter(u => u.id !== id)
        io.emit(`server:loadNotes`, notes)
    })
    socket.on(`client:toUpdate`, id => {
        let toUpdate = notes.find(u => u.id === id)
        socket.emit(`server:noteToUpdate`, toUpdate)
    })
    socket.on(`client:updatenote`, updtnote => {
        console.log(`Actualizando nota con el id: ${updtnote.id}`)

        notes = notes.map((u) => {
            if (u.id === updtnote.id) {
                u.title = updtnote.title
                u.description = updtnote.description
            }
            return u
        })
        io.emit(`server:loadNotes`, notes)
    })

    socket.on("disconnect", () => {
        console.log(socket.id, "se desconecto")
    })
})




server.listen(PORT, () => {
    console.log(`Server Listen in Port ${PORT}`)
})




// // Firebase

// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";

// const firebaseConfig = {
//     apiKey: "AIzaSyBzGOdIkWjteWCgIKQ1_Uysu8dg2Amw5xw",
//     authDomain: "notes-6c66b.firebaseapp.com",
//     projectId: "notes-6c66b",
//     storageBucket: "notes-6c66b.appspot.com",
//     messagingSenderId: "221037460405",
//     appId: "1:221037460405:web:6683e3f3e5b6dda995f7fc",
//     measurementId: "G-5EJ4D2WMF5"
// };

// // Initialize Firebase
// const firebaseApp = initializeApp(firebaseConfig);
// const analytics = getAnalytics(firebaseApp);