const notesList = document.querySelector("#notes")

let noteIDS = ""


const noteUI = (nota) => {
    const div = document.createElement("div")
    div.innerHTML += `
    <div class="card card-body rounded-0 mb-2 animate__animated animate__backInUp">
        <div class="d-flex justify-content-between">
        <h1 class="h3 card-title">${nota.title}</h1>
            <div>
            <button class="btn btn-danger delete" data-id="${nota.id}">delete</button>
            <button class="btn btn-secondary update" data-id="${nota.id}">update</button>
            </div>
        </div>
        <p>${nota.description}</p>
    </div>
    `
    const btnDelete = div.querySelector(".delete")
    const btnUpdate = div.querySelector(".update")


    btnDelete.addEventListener("click", () => {
        deletenote(btnDelete.dataset.id)
    })
    btnUpdate.addEventListener("click", () => {
        toUpdate(btnUpdate.dataset.id)
    })
    return div
}
const render_notes = (notes) => {
    console.log(notes)
    notesList.innerHTML = ""
    notes.map((u) => {
        notesList.append(noteUI(u))
    })
}

const añadirNota = (note) => {

    notesList.append(noteUI(note))

}